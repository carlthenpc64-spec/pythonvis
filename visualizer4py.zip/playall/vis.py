import os, random, time, math
import numpy as np
import pygame
from pydub import AudioSegment
from mutagen import File as MutagenFile
from rich.console import Console
from rich.panel import Panel
from rich.layout import Layout
from rich.live import Live

# -------- CONFIG --------
MUSIC_FOLDER = r"C:\Users\carlt\Desktop\pyprograms\playall" #change to where u want ur music folder to be
SUPPORTED_FORMATS = (".mp3", ".flac", ".ogg", ".wav", ".m4a")
NUM_BARS = 32
BAR_HEIGHT = 12
VISUAL_WINDOW_SEC = 0.25
REFRESH_HZ = 30
VOLUME_STEP = 0.05
SMOOTH_FACTOR = 0.6
DECAY_FACTOR = 0.85
ASCII_HEADER = r"""
╔════════════════════════════════╗
║  googols kickass music player  ║
╚════════════════════════════════╝
"""
# ------------------------

console = Console()

if os.name == "nt":
    import msvcrt
    def kb_hit(): return msvcrt.kbhit()
    def kb_get(): return msvcrt.getch().decode("utf-8", errors="ignore").lower()
else:
    def kb_hit(): return False
    def kb_get(): return None

def get_audio_files(folder):
    return [os.path.join(folder, f) for f in sorted(os.listdir(folder))
            if f.lower().endswith(SUPPORTED_FORMATS)]

def load_audio_samples(path):
    audio = AudioSegment.from_file(path)
    sr = audio.frame_rate
    arr = np.array(audio.get_array_of_samples())
    if audio.channels > 1:
        arr = arr.reshape((-1, audio.channels)).mean(axis=1)
    return arr.astype(np.float32)/(2**(8*audio.sample_width-1)), sr

def compute_bars(samples, sr, elapsed, num_bars, window_sec, max_height):
    start = int(max(0, elapsed*sr))
    end = min(len(samples), start + int(window_sec*sr))
    segment = samples[start:end]
    if len(segment) == 0:
        return [0]*num_bars
    split = np.array_split(np.abs(segment), num_bars)
    vals = [np.sqrt(np.mean(s**2)) for s in split]
    max_val = max(vals) if max(vals)>0 else 1
    return [int(min(max_height, round(v*max_height/max_val))) for v in vals]

def render_vertical_bars(heights, max_height):
    lines = []
    for row in range(max_height, 0, -1):
        line = ""
        for b in heights:
            if b >= row:
                ratio = b / max_height
                if ratio < 0.33:
                    color = "green"
                elif ratio < 0.66:
                    color = "yellow"
                else:
                    color = "red"
                line += f"[{color}]█[/]"
            else:
                line += " "
        lines.append(line)
    return "\n".join(lines)

def format_volume(vol, width=20):
    filled = int(round(vol*width))
    return f"[{'█'*filled}{'░'*(width-filled)}] {int(vol*100)}%"

def make_layout(track, nxt, elapsed, length, vol, paused, vis, shuffle, loop_mode):
    state = "⏸️" if paused else "▶️"
    loop_names = ["No Loop", "Loop One", "Loop All"]
    layout = Layout()
    layout.split_column(
        Layout(Panel(ASCII_HEADER.strip(), title=f"Mode: {'Shuffle' if shuffle else 'Normal'} | Loop: {loop_names[loop_mode]}"), ratio=1),
        Layout(Panel(vis, title="Visualizer", padding=(0,1)), ratio=3),
        Layout(Panel(f"{state} Now Playing:\n[bold cyan]{track}[/bold cyan]\nProgress: {int(elapsed)}/{int(length)} sec", title="Current Track"), ratio=2),
        Layout(Panel(f"[green]Volume:[/green] {format_volume(vol)}", title="Volume"), ratio=1),
        Layout(Panel(f"Next Track: [magenta]{nxt}[/magenta]", title="⏭Next"), ratio=1),
        Layout(Panel("[green][SPACE]pause/resume [N]next [P]prev [S]shuffle [L]loop [+/–]volume [Q]quit[/green]", title="Controls"), ratio=1)
    )
    return layout

def main():
    pygame.mixer.init()
    files = get_audio_files(MUSIC_FOLDER)
    if not files:
        console.print(f"[red]No songs found in {MUSIC_FOLDER}[/red]")
        return

    volume = 0.8
    shuffle = False
    loop_mode = 0  # 0=No Loop,1=Loop One,2=Loop All
    current_index = 0

    def get_next_index(idx):
        if shuffle:
            return random.randint(0, len(files)-1)
        else:
            return (idx + 1) % len(files)

    def get_prev_index(idx):
        if shuffle:
            return random.randint(0, len(files)-1)
        else:
            return (idx - 1) % len(files)

    while True:
        track_path = files[current_index]
        track_name = os.path.basename(track_path)
        nxt_name = os.path.basename(files[get_next_index(current_index)]) if len(files)>1 else "None"

        try:
            samples, sr = load_audio_samples(track_path)
        except Exception as e:
            console.print(f"[red]Failed to load {track_path}: {e}[/red]")
            current_index = get_next_index(current_index)
            continue

        meta = MutagenFile(track_path)
        length = meta.info.length if meta and meta.info else 0

        pygame.mixer.quit()
        pygame.mixer.init(frequency=sr)
        pygame.mixer.music.load(track_path)
        pygame.mixer.music.set_volume(volume)
        pygame.mixer.music.play()

        paused = False
        paused_time = 0
        bars = [0]*NUM_BARS
        refresh_delay = 1/REFRESH_HZ

        with Live(make_layout(track_name, nxt_name, 0, length, volume, paused, render_vertical_bars(bars, BAR_HEIGHT), shuffle, loop_mode),
                  refresh_per_second=REFRESH_HZ, console=console) as live:
            while True:
                # use pygame mixer for real elapsed time
                if paused:
                    elapsed = paused_time
                else:
                    elapsed = pygame.mixer.music.get_pos() / 1000

                new_bars = compute_bars(samples, sr, elapsed, NUM_BARS, VISUAL_WINDOW_SEC, BAR_HEIGHT)
                bars = [
                    int(old * SMOOTH_FACTOR + new * (1 - SMOOTH_FACTOR)) if new >= old
                    else int(old * DECAY_FACTOR + new * (1 - DECAY_FACTOR))
                    for old, new in zip(bars, new_bars)
                ]
                vis = render_vertical_bars(bars, BAR_HEIGHT)
                live.update(make_layout(track_name, nxt_name, elapsed, length, volume, paused, vis, shuffle, loop_mode))

                if not pygame.mixer.music.get_busy() and not paused:
                    if loop_mode == 1:  # Loop One
                        pygame.mixer.music.play()
                        continue
                    elif loop_mode == 2:  # Loop All
                        current_index = get_next_index(current_index)
                        break
                    else:
                        if current_index + 1 >= len(files):
                            console.clear()
                            console.print("[magenta]🌹 All songs played![/magenta]")
                            return
                        else:
                            current_index = get_next_index(current_index)
                            break

                if kb_hit():
                    key = kb_get()
                    if key == " ":
                        if not paused:
                            pygame.mixer.music.pause()
                            paused = True
                            paused_time = pygame.mixer.music.get_pos() / 1000
                        else:
                            pygame.mixer.music.unpause()
                            paused = False
                    elif key == "n":
                        pygame.mixer.music.stop()
                        current_index = get_next_index(current_index)
                        break
                    elif key == "p":
                        pygame.mixer.music.stop()
                        current_index = get_prev_index(current_index)
                        break
                    elif key == "s":
                        shuffle = not shuffle
                    elif key == "l":
                        loop_mode = (loop_mode + 1) % 3
                    elif key == "+":
                        volume = min(1.0, volume + VOLUME_STEP)
                        pygame.mixer.music.set_volume(volume)
                    elif key == "-":
                        volume = max(0.0, volume - VOLUME_STEP)
                        pygame.mixer.music.set_volume(volume)
                    elif key == "q":
                        pygame.mixer.music.stop()
                        console.clear()
                        console.print("[red]Quitting player...[/red]")
                        return

                time.sleep(refresh_delay)

if __name__=="__main__":
    main()
